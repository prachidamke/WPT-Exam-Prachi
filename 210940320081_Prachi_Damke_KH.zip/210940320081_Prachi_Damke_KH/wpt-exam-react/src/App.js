import logo from './logo.svg';
import './App.css';
import Messenger from './Message-app-Comp/messenger';

function App() {
  return (
   <Messenger/>
  );
}

export default App;
