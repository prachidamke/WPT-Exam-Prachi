import React from "react";
import { useState } from "react";

import axios from "axios";

export default function Messenger() {
  const [message2, setMessage] = useState("");
  const writeMessage = (e) => {
    const message1 = e.target.value;
    setMessage(message1);
  };

  const [list, setList] = useState([]);

  const sendMessage = () => {
    if (message2 != "") {
      const url = "http://localhost:4000/add-message";

      const mes = {
        message: message2,
      };
      axios.post(url, mes);
    } else alert("Message cannot be Empty!!");
    const newList = [...list, message2];
    setList(newList);
    const url2 = "http://localhost:4000/messages";
    const lis = axios.get(url2);
    const list2 = lis.data;
    const newlist = [...list, message2];
  };

  return (
    <>
      <div className="col bg-secondary ">
        <div className="text-light p-2 fs-1 fw-bold mx-4">
          MyChat-App
          <sub className="fs-6 fw-lighter ">
            {" "}
            by:- Saurabh_Patkotwar 109_Kh{" "}
          </sub>
        </div>
      </div>
      <div className="row mt-3 mx-2">
        <div className="col ">
          <input
            type="text"
            className=" w-100 p-3 rounded-1 border-1 border-dark"
            value={message2}
            placeholder="Type your message here..."
            onChange={writeMessage}
          ></input>
        </div>
        <div className="col-2 ">
          <input
            type="submit"
            className="p-3 bg-success border-1  rounded-1 text-light mx-1"
            value="Send Message"
            onClick={sendMessage}
          ></input>
        </div>
        <div>
          {list.map((items, id) => (
            <div>
              <div className="alert-secondary text-black p-2 mt-2 w-100">
                <div className={id % 2 == 0 ? "text-start" : "text-end"}>
                  {items}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
