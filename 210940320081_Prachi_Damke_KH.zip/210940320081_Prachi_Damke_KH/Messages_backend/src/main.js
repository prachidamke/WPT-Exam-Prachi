const express = require("express");

const app = express();
app.use(express.json());
const cors = require("cors");
app.use(cors());

const { selectAllUser, addUser } = require("./user");

app.get("/messages", async (req, res) => {
  const list = await selectAllUser();
  console.log("Connection request was Successful!!");
  res.json(list);
});


app.post("/add-message", async (req, res) => {
  const reciv = req.body;
  await addUser(reciv);
  console.log("Message sent Successfully!!");
  res.json({ message: "Message sent Successfully!!" });
});


app.listen(4000, () => console.log("Server Started!!"));